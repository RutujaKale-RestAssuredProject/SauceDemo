package ParallelTests;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.excel.lib.util.Xls_Reader;
import PageObjects.UserDetails;

public class TC001_SauceDemoURLTesting {

	public WebDriver driver;

	@Parameters("browser")
	@BeforeClass
	public void BeforeTest(String browser) throws Exception {

		//Check if parameter passed from TestNG is 'Firefox'
		if (browser.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver","C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\GeckoDriver.exe");
			//create Firefox instance
			driver = new FirefoxDriver();		      
		}
		//Check if parameter passed from TestNG is 'Chrome'
		else if (browser.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", 
					"C:\\Users\\Techno\\Desktop\\Jmeter\\chromedriver.exe");
			//create chrome instance
			driver = new ChromeDriver();
		}
		//Check if parameter passed from TestNG is 'Edge'
		else if (browser.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver", 
					"C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\msedgedriver.exe");
			//create Internet Explorer instance
			driver = new EdgeDriver ();
		}

		else{
			//If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority=0)
	// Once Before method is completed, Test method will start
	public void login() throws InterruptedException, IOException{

		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(10000);

		//Valid Login
		WebElement userName = driver.findElement(By.id("user-name"));
		WebElement pwd = driver.findElement(By.id("password"));

		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		String sheetName = "login";

		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String UserName = reader.getCellData(sheetName, "username", rowNum);
			String Password = reader.getCellData(sheetName, "password", rowNum);

			//System.out.println(UserName + " " + Password);
			userName.sendKeys(UserName);
			pwd.sendKeys(Password);

			driver.findElement(By.id("login-button")).click();
			Thread.sleep(10000);

		}
		
		System.out.println("User Successfully Logged In!");
		
		File UserProfileLoggedIn = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(UserProfileLoggedIn, new File("C:/TC001_SauceDemoURLTesting/UserProfileLoggedIn.jpg"));
		Thread.sleep(5000);
	}

	@Test(priority=1)
	// Once Before method is completed, Test method will start
	public void AddingProductToCart() throws InterruptedException, IOException{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		UserDetails Details = new UserDetails (driver);

		//Sort the list as per High to Low
		Select se = new Select(driver.findElement(By.className("product_sort_container")));
		System.out.println("Sorting as Low to High!");
		se.selectByValue("lohi");
		System.out.println("");		

		//verify product and Add first 3 products to cart
		for (int i=0; i<=2; i++)
		{
			driver.findElement(By.xpath(".//button[contains(text(),'Add to cart')]")).click();
			System.out.println("Item "+ i + " Added to Cart");
			Thread.sleep(5000);	
		}
		System.out.println("The 3 Products added in the cart!");
		System.out.println("");

		File ListPage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(ListPage, new File("C:/TC001_SauceDemoURLTesting/ListPage.jpg"));
		Thread.sleep(5000);		

		driver.findElement(By.className("shopping_cart_link")).click();
		Thread.sleep(5000);
		
		//Get the name and price of all products in Cart
		System.out.println("The Products added in the cart as below -->");
		System.out.println("Item 1 = " + driver.findElement(By.xpath("(.//div[@class='inventory_item_name'])[1]")).getText());
		System.out.println("Price for Item 1 = " + driver.findElement(By.xpath("(.//div[@class='inventory_item_price'])[1]")).getText());
		System.out.println("");
		
		System.out.println("Item 2 = " + driver.findElement(By.xpath("(.//div[@class='inventory_item_name'])[2]")).getText());
		System.out.println("Price for Item 2 = " + driver.findElement(By.xpath("(.//div[@class='inventory_item_price'])[2]")).getText());
		System.out.println("");
		
		System.out.println("Item 3 = " + driver.findElement(By.xpath("(.//div[@class='inventory_item_name'])[3]")).getText());
		System.out.println("Price for Item 3 = " + driver.findElement(By.xpath("(.//div[@class='inventory_item_price'])[3]")).getText());
		System.out.println("");
		
		File CartProducts = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CartProducts, new File("C:/TC001_SauceDemoURLTesting/CartProducts.jpg"));
		Thread.sleep(5000);
		
		//verify product and Remove 2 products from cart
		for (int i=0; i<=1; i++)
		{
			driver.findElement(By.xpath(".//button[contains(text(),'Remove')]")).click();
			System.out.println("Item "+ i + " removed from Cart");
			Thread.sleep(5000);
		}
		
		System.out.println("2 Items removed from Cart!");	
		System.out.println("");

		File FinalCartProducts = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(FinalCartProducts, new File("C:/TC001_SauceDemoURLTesting/FinalCartProducts.jpg"));
		Thread.sleep(5000);
		
		//Get the Name and the value of the final product in cart
		System.out.println("Final Product in the cart as below -->");
		System.out.println("Item 1 = " + driver.findElement(By.xpath("(.//div[@class='inventory_item_name'])[1]")).getText());
		System.out.println("Price for Item 1 = " + driver.findElement(By.xpath("(.//div[@class='inventory_item_price'])[1]")).getText());
		Thread.sleep(5000);
		System.out.println("");
		
		driver.findElement(By.id("checkout")).click();
		Thread.sleep(5000);

		//User Details Page
		Details.User_Details();
		System.out.println("User Details successfully added!");		
		System.out.println("");

		File UserDetails = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(UserDetails, new File("C:/TC001_SauceDemoURLTesting/UserDetails.jpg"));
		Thread.sleep(5000);		

		driver.findElement(By.id("continue")).click();

		//CheckOut Page
		System.out.println("Payment Information = " + driver.findElement(By.className("summary_value_label")).getText());		
		System.out.println(driver.findElement(By.className("summary_subtotal_label")).getText());
		System.out.println(driver.findElement(By.className("summary_tax_label")).getText());
		System.out.println(driver.findElement(By.className("summary_total_label")).getText());
		System.out.println("");

		File CheckOutPage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CheckOutPage, new File("C:/TC001_SauceDemoURLTesting/CheckOutPage.jpg"));
		Thread.sleep(5000);		

		//Finish
		driver.findElement(By.id("finish")).click();
		Thread.sleep(5000);	

		File FinishPage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(FinishPage, new File("C:/TC001_SauceDemoURLTesting/FinishPage.jpg"));
		Thread.sleep(5000);	
		System.out.println("<<<<<<The Test Case Succesfully Completed>>>>>>");

	}

	@AfterClass 
	public void afterTest() {
		driver.quit();
		System.out.println("<<<<<<The browser is closed>>>>>>");		
	}

}